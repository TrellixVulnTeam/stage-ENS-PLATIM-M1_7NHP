## Load a pre-trained model

* This network has been trained on 2D epithelial cells. 

## Create the model

* Press 'Go' to load the selected model (Note that loading a model can take a lot of time, up to several minutes so please be patient).