# Output predictions to

* **Auto: By default files are saved in 'predict' directory within the input folder** 
* **Tissue Analyzer:** If selected, files will be saved within the input folder in a directory that has the same name as the input file without the extensions (e.g. the prediction for the 'test_0.tif' file will be saved in a directory called 'test_0'). This output is compatible with tissue analyzer.
* **Custom directory:** If selected files are saved in a user defined directory