# Preview ROI

In some cases, only a region of the user input/ground truth images must be used for training a model. When that is the case it is possible to manually draw the ROI over the 'preview' image. The model will then be trained on a crop of the specified ROI.