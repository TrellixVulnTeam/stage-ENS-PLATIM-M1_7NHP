# Pre-processing images

Pre-trained models were trained on images having a dark background. Therefore, **if the epithelial images to segment have a white background, you must tick 'invert'.**